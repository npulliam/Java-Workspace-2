package com.nathanpulliam.updateanddelete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateAndDeleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
